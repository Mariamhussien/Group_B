-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 18, 2016 at 03:28 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `max_discount_pst` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `stock_quantity` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `discount_pct` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `image`, `stock_quantity`, `price`, `discount_pct`, `cat_id`) VALUES
(1, 'black_Adress', 'http://www.becauseclothing.com/wp-content/uploads/2012/04/mini-dresses-for-women.jpg', 3, '500', 100, 1),
(2, 'T-Shirt', 'https://image.spreadshirtmedia.com/image-server/v1/products/111465954/views/1,width=378,height=378,appearanceId=506,version=1443074494/Goth-Girl---Front.png-Women-s-T-Shirts.png', 5, '200', 30, 1),
(3, 'blue jeans', 'http://www.clker.com/cliparts/4/7/8/1/12576756251927385023secretlondon_Jeans.svg.med.png', 3, '150', 40, 1),
(4, 'woman T-shirt', 'https://image.spreadshirtmedia.com/image-server/v1/products/17326516/views/1,width=378,height=378,appearanceId=311,version=1320836481/dance-quote-1-Women-s-T-Shirts.png', 4, '200', 90, 1),
(5, 'sport-suit', 'http://g03.a.alicdn.com/kf/HTB1KavtIVXXXXc.XFXXq6xXFXXXh/cool-2015-winter-tracksuit-women-clothing-hoodies-set-sport-suit-women-sets-sports-costumes-women-sweatshirt.jpg', 2, '190', 80, 1),
(6, 'Bink Adress', 'http://data.whicdn.com/images/58280079/large.png', 3, '3000', 400, 1),
(7, 'blaack-shoes', 'http://data.whicdn.com/images/58280079/large.png', 4, '150', 50, 2),
(8, 'winter shoes', 'http://i01.i.aliimg.com/wsphoto/v0/1071768849/Free-shipping-big-size-ankle-martin-fashion-boots-for-women-shoes-woman-2013-ladies-chunky-heels.jpg', 6, '300', 100, 2),
(9, 'half boot', 'http://myshoesjournal.com/wp-content/uploads/2013/01/elegance-leather-boots.jpg', 3, '200', 90, 2),
(10, 'black-boot', 'http://www.dhresource.com/0x0s/f2-albu-g1-M00-AE-51-rBVaGVXNYsmACno2AAIwnScwF-M935.jpg/2015-new-fashion-woman-shoes-boots-pure-color.jpg', 5, '230', 90, 2),
(11, 'Accessories1', 'http://www.stylein.xyz/wp-content/uploads/2015/01/Desire-Accessories-Collection-20157.jpg', 4, '30', 0, 3),
(12, 'Accessories2', 'http://image.dhgate.com/0x0/f2/albu/g2/M01/7F/C5/rBVaGlWjY-qARwcVAACbVvGUkI8457.jpg', 3, '50', 10, 3),
(13, 'accessories3', 'http://www.yoummisr.com/en/wp-content/uploads/2014/12/Latest-designs-Women-Accessories-Girls-2015-2016-2.jpg', 6, '70', 20, 3),
(14, 'accessories4', 'http://g04.a.alicdn.com/kf/HTB1rJpgJFXXXXb5XXXXq6xXFXXXJ/Newei-Drop-Cat-Collar-Dangle-Earrings-Acrylic-Pattern-New-2015-Charm-Girl-Woman-Jewelry-Accessories-Fashion.jpg', 5, '50', 20, 3),
(15, 'black-suit', 'https://s-media-cache-ak0.pinimg.com/736x/c4/4e/04/c44e0488d7f8f2a990b43eb2f2bd5cec.jpg', 4, '300', 80, 4),
(16, 'black jacket suit', 'http://assets.menshealth.co.uk/main/thumbs/31190/or_610af259126625656521432-2.jpg', 5, '400', 90, 4),
(17, 'green one', 'http://g01.a.alicdn.com/kf/HTB1OenzJFXXXXXEXXXXq6xXFXXXX/2015-New-Autumn-Fashion-Brand-font-b-Men-b-font-font-b-Clothes-b-font-Slim.jpg', 4, '200', 90, 4),
(18, 'blue jeans', 'http://images.ttcdn.co/media/i/product/90404-e474bf347c14431588b4280ee80ef8d2.jpeg?size=300', 5, '150', 50, 4),
(19, 'classic shoes', 'http://www.bagshoes.net/img/man-shoes-new-men-shoes97.jpg', 7, '190', 30, 5),
(20, 'half boot', 'http://g02.a.alicdn.com/kf/HTB1kfUQJFXXXXaTXFXXq6xXFXXX3/2015-new-genuine-leather-short-Boots-Autumn-winter-martin-man-shoes-Motorcycle-Warm-Snow-boots-British.jpg', 3, '160', 20, 5),
(21, 'sport shoes', 'http://www.airjordanplus.com/images/nike-zoom-speed-racer-man-shoes-white-black-365943-311-554-0.jpg', 6, '140', 30, 5),
(22, 'white and black shoes', 'http://g03.a.alicdn.com/kf/HTB1ChJbJpXXXXaKaXXXq6xXFXXXy/2016-Spring-And-Autumn-high-quality-man-shoes-fashion-Flats-Lacing-canvas-shoe-men-breathable-pu.jpg', 5, '130', 0, 5),
(23, 'red adress', 'http://image.dhgate.com/albu_363288499_00/1.0x0.jpg', 7, '290', 90, 6),
(24, 'casual tranning clothes', 'http://i01.i.aliimg.com/wsphoto/v0/823903655_1/5pcs-lot-2013-fashion-summer-kids-clothing-baby-boys-short-sleeves-printed-plaid-t-shirts.jpg', 8, '90', 0, 6),
(25, 'red-white baby adress', 'http://i00.i.aliimg.com/wsphoto/v0/891747996/Promotion-lovely-polka-dot-kids-dress-with-bow-little-girls-summer-dresses-2013-for-0-5.jpg', 4, '130', 40, 6),
(26, 'summer clothes', 'https://s-media-cache-ak0.pinimg.com/236x/f2/91/62/f29162777b0a03d76c68932affc7847a.jpg', 4, '200', 80, 6);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
